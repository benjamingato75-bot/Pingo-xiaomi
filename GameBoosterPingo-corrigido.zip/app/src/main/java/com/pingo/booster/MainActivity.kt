package com.pingo.booster

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val pad by lazy { (16 * resources.displayMetrics.density).toInt() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        montarTela()
    }

    private fun montarTela() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "🐧 Game Booster Pingo"
            textSize = 24f
            gravity = Gravity.CENTER
            setPadding(0, pad, 0, pad / 2)
        })

        root.addView(TextView(this).apply {
            text = "1) Permita aparecer sobre outros apps\n2) (Opcional) Permita Não Perturbe\n3) Ligue o painel\n4) Abra um jogo — a alça fica na borda esquerda"
            textSize = 14f
            setPadding(0, 0, 0, pad)
        })

        addButton(root, "1. Permitir aparecer sobre outros apps") {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        }

        addButton(root, "2. Permitir acesso ao Não Perturbe") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }

        addButton(root, "3. LIGAR painel flutuante") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(
                    this,
                    "Primeiro permita aparecer sobre outros apps (passo 1).",
                    Toast.LENGTH_LONG
                ).show()
                return@addButton
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
            }
            val serviceIntent = Intent(this, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            Toast.makeText(
                this,
                "Painel ligado. Arraste a alça azul da esquerda para abrir.",
                Toast.LENGTH_LONG
            ).show()
        }

        addButton(root, "DESLIGAR painel") {
            stopService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "Painel desligado.", Toast.LENGTH_SHORT).show()
        }

        root.addView(TextView(this).apply {
            text = "\nAPLICATIVOS INSTALADOS\nToque para abrir (depois use a alça no jogo)."
            textSize = 16f
            setPadding(0, pad, 0, pad / 2)
        })

        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(launcher, PackageManager.MATCH_ALL)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }

        if (apps.isEmpty()) {
            root.addView(TextView(this).apply { text = "Nenhum aplicativo encontrado." })
        } else {
            apps.forEach { info ->
                val label = info.loadLabel(packageManager).toString()
                addButton(root, "▶  $label") {
                    val launch = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)
                    if (launch != null) startActivity(launch)
                    else Toast.makeText(this, "Não foi possível abrir $label", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun addButton(root: LinearLayout, label: String, action: () -> Unit) {
        root.addView(Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        })
    }
}
